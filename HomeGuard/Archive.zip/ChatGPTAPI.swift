import Foundation

class ChatGPTAPI {
    
    static func fetchAutomation(prompt: String, completion: @escaping (AutomationRule?) -> Void) {
        let apiKey = "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"
        let url = URL(string: "https://api.openai.com/v1/chat/completions")!
        let body: [String: Any] = [
            "model": "gpt-4",
            "messages": [["role": "user", "content": prompt]],
            "temperature": 0.7
        ]
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data,
                  error == nil,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let choices = json["choices"] as? [[String: Any]],
                  let message = choices.first?["message"] as? [String: Any],
                  let content = message["content"] as? String
            else {
                completion(nil)
                return
            }
            
            // Attempt to decode content as an array of AutomationRule
            guard let automationData = content.data(using: .utf8) else {
                completion(nil)
                return
            }
            do {
                let rules = try JSONDecoder().decode([AutomationRule].self, from: automationData)
                // We only care about the first item
                let singleRule = rules.first
                completion(singleRule)
            } catch {
                print("Decoding array of AutomationRules failed: \(error)")
                completion(nil)
            }
        }.resume()
    }
}
