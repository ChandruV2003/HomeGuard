import SwiftUI

struct HomeGuardMainView: View {
    var body: some View {
        DashboardView()
    }
}

struct HomeGuardMainView_Previews: PreviewProvider {
    static var previews: some View {
        HomeGuardMainView()
    }
}
