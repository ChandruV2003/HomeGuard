import SwiftUI
import UIKit

class MjpegStreamViewModel: NSObject, ObservableObject, URLSessionDataDelegate {
    // The latest frame from the stream.
    @Published var image: UIImage?

    private var dataTask: URLSessionDataTask?
    private var session: URLSession?
    private var currentData = Data()

    // The boundary in your ESP32-CAM stream (set in firmware).
    private let boundaryString = "--frame\r\n"

    // Starts streaming from the given URL.
    func startStreaming(url: URL) {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = .infinity
        config.timeoutIntervalForResource = .infinity

        session = URLSession(configuration: config, delegate: self, delegateQueue: OperationQueue())
        dataTask = session?.dataTask(with: url)
        dataTask?.resume()
    }

    func stopStreaming() {
        dataTask?.cancel()
        session?.invalidateAndCancel()
        session = nil
    }

    // MARK: - URLSessionDataDelegate

    // Add the didCompleteWithError delegate method for error logging.
    func urlSession(_ session: URLSession,
                    dataTask: URLSessionDataTask,
                    didReceive data: Data) {
        print("Received \(data.count) bytes from ESP‐CAM")
        currentData.append(data)

        while let boundaryRange = currentData.range(of: boundaryData()) {
            let frameData = currentData[..<boundaryRange.lowerBound]
            currentData.removeSubrange(..<boundaryRange.upperBound)
            if let image = extractJPEG(from: frameData) {
                DispatchQueue.main.async {
                    self.image = image
                }
            }
        }
    }


    // Convert the boundary string to Data for searching.
    private func boundaryData() -> Data {
        boundaryString.data(using: .utf8) ?? Data()
    }

    private func extractJPEG(from data: Data) -> UIImage? {
        guard
            let startRange = data.range(of: Data([0xFF, 0xD8])),
            let endRange = data.range(of: Data([0xFF, 0xD9]),
                                        options: [],
                                        in: startRange.lowerBound..<data.endIndex)
        else {
            return nil
        }
        let jpegData = data[startRange.lowerBound..<endRange.upperBound]
        return UIImage(data: jpegData)
    }
}

struct CameraLivestreamView: View {
    let streamURL: URL

    @StateObject private var viewModel = MjpegStreamViewModel()

    var body: some View {
        GeometryReader { geometry in
            if let image = viewModel.image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width,
                           height: geometry.size.height)
                    .clipped()
            } else {
                Text("Loading Stream...")
                    .frame(width: geometry.size.width, height: geometry.size.height)
            }
        }
        // Start streaming when the view appears.
        .onAppear {
            viewModel.startStreaming(url: streamURL)
        }
        // Stop streaming when the view disappears (e.g. navigates away).
        .onDisappear {
            viewModel.stopStreaming()
        }
    }
}

struct CameraLivestreamView_Previews: PreviewProvider {
    static var previews: some View {
        // Change to your actual ESP32-CAM IP and port
        CameraLivestreamView(streamURL: URL(string: "http://172.20.10.6:81/stream")!)
    }
}
